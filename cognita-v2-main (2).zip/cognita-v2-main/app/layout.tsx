import './globals.css'
import AppShell from '@/components/layout/AppShell'
import NotificationListener from '@/components/ui/NotificationListener'

export const metadata = {
  title: 'Cognita',
  description: 'Okuma platformu',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <head>
        <script dangerouslySetInnerHTML={{ __html: `
          (function(){
            try {
              var t = localStorage.getItem('theme') || 'light';
              var isDark = t === 'dark' || (t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
              document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
            } catch(e){}
          })();
        `}} />
      </head>
      <body>
        <AppShell>
          <NotificationListener />
          {children}
        </AppShell>
      </body>
    </html>
  )
}
